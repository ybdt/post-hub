//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� Script.rc ʹ��
//
#define IDD_DIALOG                      101
#define IDR_WAVE                        102
#define IDI_ICON1                       104
#define IDI_ICON_MAIN                   104
#define IDI_ICON2                       105
#define IDI_ICON_MSG                    105
#define IDC_EDIT_MESSAGE                1000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
